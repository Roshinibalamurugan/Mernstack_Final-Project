// import React from 'react';

// const FoodCard = ({ food }) => {
//   return (
//     <div className="food-card">
//       <img src={food.imageUrl} alt={food.name} />
//       <h3>{food.name}</h3>
//       <p>{food.description}</p>
//       <p>${food.price}</p>
//       <button>Add to Cart</button>
//     </div>
//   );
// };

// export default FoodCard;
