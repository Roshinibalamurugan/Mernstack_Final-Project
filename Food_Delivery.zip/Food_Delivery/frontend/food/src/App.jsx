import React, { useState } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Home from './webpages/Home';
import Menu from './webpages/Menu';
import Cart from './webpages/Cart';
import Checkout from './webpages/Checkout';

const App = () => {
  const [cart, setCart] = useState([]); 

  const addToCart = (dish) => {
    setCart((prevCart) => {
      const existingDish = prevCart.find(item => item.id === dish.id);
      if (existingDish) {
        return prevCart.map(item => 
          item.id === dish.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      } else {
        return [...prevCart, { ...dish, quantity: 1 }];
      }
    });
  };

  return (
    <Router>
      <div>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/menu" element={<Menu addToCart={addToCart} />} />
          <Route path="/cart" element={<Cart cartItems={cart} setCartItems={setCart} />} />
          <Route path="/checkout" element={<Checkout cartItems={cart} />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
