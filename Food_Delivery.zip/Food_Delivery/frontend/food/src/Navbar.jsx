import React from 'react';
import { Link } from 'react-router-dom';

const Navbar = () => {
  return (
    <nav style={styles.navbar}>
      <div style={styles.logoContainer}>
        <h1 style={styles.logo}>TastyBites</h1>
      </div>
      <ul style={styles.navLinks}>
        <li style={styles.navItem}>
          <Link to="/" style={styles.link}>Home</Link>
        </li>
        <li style={styles.navItem}>
          <Link to="/menu" style={styles.link}>Menu</Link>
        </li>
        <li style={styles.navItem}>
          <Link to="/cart" style={styles.link}>Cart</Link>
        </li>
        <li style={styles.navItem}>
          <Link to="/checkout" style={styles.link}>Checkout</Link>
        </li>
      </ul>    
    </nav> 
  );
};

const styles = {
  navbar: {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '10px 30px',
    backgroundColor: '#333',
    color: 'white',
    position: 'fixed',
    width: '100%',
    top: 0,
    zIndex: 1000,
  },
  logoContainer: {
    fontSize: '24px',
    fontWeight: 'bold',
    letterSpacing: '2px',
  },
  logo: {
    color: '#f39c12',
    margin: 0,
  },
  navLinks: {
    display: 'flex',
    listStyle: 'none',
    margin: 0,
    padding: 0,
    flexGrow: 1,
    justifyContent: 'center',
  },
  navItem: {
    margin: '0 15px',
  },
  link: {
    textDecoration: 'none',
    color: 'white',
    fontSize: '16px',
    transition: 'color 0.3s ease',
  },
  linkHover: {
    color: '#f39c12',
  },
  contactContainer: {
    fontSize: '14px',
    fontWeight: 'lighter',
  },
  contact: {
    margin: 0,
    color: '#f39c12',
  }
};

export default Navbar;
